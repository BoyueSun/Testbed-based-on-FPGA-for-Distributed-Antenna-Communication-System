#include <stdio.h>
#include <string.h>
#include "lwip/err.h"
#include "lwip/tcp.h"
#include "xil_types.h"
#include "xparameters.h"
#include "xil_io.h"
#include "xil_printf.h"
#include "mm2s_controller.h"

#define DDR_BASEADDR XPAR_DDR_MEM_BASEADDR + 0x20000000
#define CHUNK_SIZE 1024


static u32 ddr_write_offset = 0;  // Record the current address in DDR
static u8 is_initialized = 0;     // Flag to track initialization status
u8 send_buffer[MAX_SAMP_BYTE_SIZE];
static u32 expected_samples = 0;




int transfer_data() {
    return 0;
}

void print_app_header()
{
#if (LWIP_IPV6==0)
    xil_printf("\n\r\n\r-----lwIP TCP echo server ------\n\r");
#else
    xil_printf("\n\r\n\r-----lwIPv6 TCP echo server ------\n\r");
#endif
    xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}


// Structure to manage chunked sending
typedef struct {
    u8 *buffer;
    u32 total_size;
    u32 sent;
    u32 acked;
} tcp_send_state_t;




void send_data_in_chunks(struct tcp_pcb *tpcb, tcp_send_state_t *state)
{
    if(state->sent < state->total_size) {
        u16_t space = tcp_sndbuf(tpcb);
        xil_printf(" Space in buffer is: %d\n\r", space);
        if (space == 0) {
            xil_printf(" No buffer space left. Waiting...\n\r");
            return;
        }else {//if (space > 4096) {

        size_t chunk_len = LWIP_MIN(state->total_size - state->sent, space);

        err_t err = tcp_write(tpcb, state->buffer + state->sent, chunk_len, TCP_WRITE_FLAG_COPY);
        if (err != ERR_OK) {
            xil_printf(" Failed to queue data: %d\n\r", err);
            free(state->buffer);
            free(state);
            return;
        }

        state->sent += chunk_len;
        tcp_output(tpcb);

        }



    }
}
// Sent callback to continue sending when buffer space is available
static err_t my_tcp_sent_callback(void *arg, struct tcp_pcb *tpcb, u16_t len)
{
    tcp_send_state_t *state = (tcp_send_state_t *)arg;

    state->acked += len;

    xil_printf(" Received data in sent_callback %d\n\r", len);
    if(state->acked == state->sent)
    {
        if (state->sent >= state->total_size) {
        xil_printf(" All data sent successfully.\n\r");
        free(state->buffer);
        free(state);
        tcp_sent(tpcb, NULL);  // Unregister callback
        } else {
            send_data_in_chunks(tpcb, state);
        }
    }


    return ERR_OK;
}



err_t recv_callback(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err)
{
    int Status;

	if (!p) {
        tcp_close(tpcb);
        tcp_recv(tpcb, NULL);
        return ERR_OK;
    }

    tcp_recved(tpcb, p->len);

    xil_printf("Data Received, length: %d bytes\r\n", p->len);

    u8 *payload_ptr = (u8 *)p->payload;

    //  tx00 + 4 bytes length of data
    //static u32 expected_samples = 0;

    if (p->len == 8 &&
        payload_ptr[0] == 't' &&
        payload_ptr[1] == 'x' &&
        payload_ptr[2] == '0' &&
        payload_ptr[3] == '0') {  // "tx00"

        // Read sample quantity (int32)
        expected_samples = *((u32 *)(payload_ptr + 4));
        xil_printf(" Tx Expected sample count received: %d\n\r", expected_samples);

        pbuf_free(p);
        return ERR_OK;
    }


    // tx01
    if (p->len == 4 &&
        payload_ptr[0] == 't' &&
        payload_ptr[1] == 'x' &&
        payload_ptr[2] == '0' &&
        payload_ptr[3] == '1') {  // "tx01"
        ddr_write_offset = 0;  // DDR offset
        is_initialized = 1;    // Set initialization flag
        xil_printf("Received initialization command, DDR offset reset\n\r");
        xil_printf("Current DDR offset %d \n\r", ddr_write_offset);

        // Send confirmation message "tx02"
        u8 ack_msg[4] = {'t', 'x', '0', '2'};
        if (tcp_sndbuf(tpcb) > 4) {
            err = tcp_write(tpcb, ack_msg, 4, 1);
            if (err != ERR_OK) {
                xil_printf("Failed to send initialization ACK\n\r");
            } else {
                tcp_output(tpcb);
            }
        } else {
            xil_printf("no space in tcp_sndbuf for ACK\n\r");
        }

        pbuf_free(p);
        return ERR_OK;
    }

    if (p->len == 4 &&
		payload_ptr[0] == 't' &&
		payload_ptr[1] == 'x' &&
		payload_ptr[2] == '0' &&
		payload_ptr[3] == '3') {  // "tx00"

		// Read sample quantity (int32)
    	Status = prepare_hw_for_transfer(HW_DMA_RESET);
    	if (Status != XST_SUCCESS) {
			xil_printf("HW reset failed!\r\n");
			return XST_FAILURE;
		}
		xil_printf(" Tx stop recieved\n\r");

		pbuf_free(p);
		return ERR_OK;
	}

    if (p->len == 8 &&
		payload_ptr[0] == 'r' &&
		payload_ptr[1] == 'x' &&
		payload_ptr[2] == '0' &&
		payload_ptr[3] == '0') {  // "tx00"

		// Read sample quantity (int32)
		expected_samples = *((u32 *)(payload_ptr + 4));
		xil_printf("Rx Expected sample count received: %d\n\r", expected_samples);

		pbuf_free(p);
		return ERR_OK;
	}

    //  Processing read request rx01
    if (p->len == 4 &&
        payload_ptr[0] == 'r' &&
        payload_ptr[1] == 'x' &&
        payload_ptr[2] == '0' &&
        payload_ptr[3] == '1') {  // "rx01"

        xil_printf("Received read command (rx01)\n\r");

//        if (ddr_write_offset == 0) {
//            xil_printf("DDR is empty, no data to send.\n\r");
//            pbuf_free(p);
//            return ERR_OK;
//        }
        Status = prepare_hw_for_transfer(HW_S2MM_DIR);
		if (Status != XST_SUCCESS) {
			xil_printf("HW prep Rx failed!\r\n");
			return XST_FAILURE;
		}

		Status = s2mm_controller(DDR_BASEADDR, expected_samples*4);
		if (Status != XST_SUCCESS) {
			xil_printf("DMA Rx failed!\r\n");
			return XST_FAILURE;
		}

        xil_printf("Sending DDR contents. Total offset: %d bytes\n\r", expected_samples*4);

        u32 data_size = expected_samples*4 ;
        xil_printf("Total number of samples = %d samples\n\r", expected_samples);

        // === Real Part ===
        if (data_size <= MAX_SAMP_BYTE_SIZE) {
            for (int i = 0; i < data_size; i++) {
                u16 data16 = Xil_In16(DDR_BASEADDR + i * 2);
                memcpy(send_buffer + i * 2, &data16, 2);
            }
            xil_printf("Anything\n\r");


            tcp_send_state_t *state = calloc(1, sizeof(tcp_send_state_t));
            state->buffer = send_buffer;
            state->total_size = data_size;
            state->sent = 0;
            state->acked = 0;

            tcp_sent(tpcb, my_tcp_sent_callback);
            tcp_arg(tpcb, state);

            xil_printf("Starting to send real part...\n\r");
            send_data_in_chunks(tpcb, state);
        } else {
            xil_printf("Failed to allocate memory for real part\n\r");
        }

        pbuf_free(p);
        return ERR_OK;
    }

    // Writing data
    if (is_initialized) {
        // Writing data to DDR
        u16 data16;
        for (int i = 0; i < p->len; i += 2) {
            data16 = 0;
            memcpy(&data16, payload_ptr + i, (p->len - i >= 2) ? 2 : (p->len - i));
            Xil_Out16(DDR_BASEADDR + ddr_write_offset, data16);
            ddr_write_offset += 2;
        }
        xil_printf("Data written to DDR, current offset: %d\n\r", ddr_write_offset);

        // Determine whether the reception is complete.
        if (ddr_write_offset == expected_samples * 4) {
            xil_printf("All real + imag data received: %d samples total\n\r", expected_samples);
            is_initialized = 0;  // Stop reception

            Status = prepare_hw_for_transfer(HW_MM2S_DIR);
            if (Status != XST_SUCCESS) {
				xil_printf("HW prep Tx failed!\r\n");
				return XST_FAILURE;
			}

            Status = mm2s_controller(DDR_BASEADDR, ddr_write_offset);
            if (Status != XST_SUCCESS) {
				xil_printf("DMA Tx failed!\r\n");
				return XST_FAILURE;
			}
        }
    }

    pbuf_free(p);
    return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err)
{
    static int connection = 1;

    tcp_recv(newpcb, recv_callback);
    tcp_arg(newpcb, (void*)(UINTPTR)connection);

    connection++;
    return ERR_OK;
}

int start_application()
{
    struct tcp_pcb *pcb;
    err_t err;
    unsigned port = 7;

    pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);
    if (!pcb) {
        xil_printf("Error creating PCB. Out of Memory\n\r");
        return -1;
    }

    err = tcp_bind(pcb, IP_ANY_TYPE, port);
    if (err != ERR_OK) {
        xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
        return -2;
    }

    tcp_arg(pcb, NULL);
    pcb = tcp_listen(pcb);
    if (!pcb) {
        xil_printf("Out of memory while tcp_listen\n\r");
        return -3;
    }

    tcp_accept(pcb, accept_callback);

    xil_printf("TCP echo server started @ port %d\n\r", port);

   return 0;
}
