/***************************** Include Files *********************************/
#include "xaxidma.h"
#include "xaxis_switch.h"
#include "xuartps.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xdebug.h"
#include "xil_printf.h"
#include "xgpio.h"
#include "xil_util.h"
#ifdef SDT
#include "xinterrupt_wrap.h"
#endif

#ifdef __aarch64__
#include "xil_mmu.h"
#endif

#ifdef XPAR_UARTNS550_0_BASEADDR
#include "xuartns550_l.h"       /* to use uartns550 */
#endif

#ifndef DEBUG
extern void xil_printf(const char *format, ...);
#endif

#ifndef SDT
#ifdef XPAR_INTC_0_DEVICE_ID
#include "xintc.h"
#else
#include "xscugic.h"
#endif
#endif

/******************** Constant Definitions **********************************/
/*
 * Device hardware build related constants.
 */

#ifndef SDT
#define DMA_DEV_ID		XPAR_AXIDMA_0_DEVICE_ID
#define XAXIS_SWITCH_DEVICE_ID		XPAR_AXIS_SWITCH_0_DEVICE_ID
#define UART_DEVICE_ID		XPAR_XUARTPS_0_DEVICE_ID

#ifdef XPAR_AXI_7SDDR_0_S_AXI_BASEADDR
#define DDR_BASE_ADDR		XPAR_AXI_7SDDR_0_S_AXI_BASEADDR
#elif defined (XPAR_MIG7SERIES_0_BASEADDR)
#define DDR_BASE_ADDR	XPAR_MIG7SERIES_0_BASEADDR
#elif defined (XPAR_MIG_0_C0_DDR4_MEMORY_MAP_BASEADDR)
#define DDR_BASE_ADDR	XPAR_MIG_0_C0_DDR4_MEMORY_MAP_BASEADDR
#elif defined (XPAR_PSU_DDR_0_S_AXI_BASEADDR)
#define DDR_BASE_ADDR	XPAR_PSU_DDR_0_S_AXI_BASEADDR
#endif

#else

#ifdef XPAR_MEM0_BASEADDRESS
#define DDR_BASE_ADDR		XPAR_MEM0_BASEADDRESS
#endif
#endif

/*
 * The following constant controls the length of the buffers to be sent
 * and received with the UART,
 */
#define TEST_BUFFER_SIZE	(8200)

// Defines the maximum number of samples that the system can handle in bytes
#define MAX_SAMP_BYTE_SIZE  (130000)//(400000)

#ifndef DDR_BASE_ADDR
#warning CHECK FOR THE VALID DDR ADDRESS IN XPARAMETERS.H, \
DEFAULT SET TO 0x01000000
#define MEM_BASE_ADDR		(0x01000000)
#else
#define MEM_BASE_ADDR		(DDR_BASE_ADDR + 0x1000000)
#endif

#ifndef SDT
#ifdef XPAR_INTC_0_DEVICE_ID
#define RX_INTR_ID		XPAR_INTC_0_AXIDMA_0_S2MM_INTROUT_VEC_ID
#define TX_INTR_ID		XPAR_INTC_0_AXIDMA_0_MM2S_INTROUT_VEC_ID
#else
#define RX_INTR_ID		XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR
#define TX_INTR_ID		XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR
#endif
#endif

#define GPIO_ADC_ENABLE_DEVICE_ID	XPAR_AXI_GPIO_ADC_0_DEVICE_ID
#define GPIO_RX_LEN_DEVICE_ID		XPAR_AXI_GPIO_RX_LEN_DEVICE_ID

#define GPIO_CHANNEL		(1)

#define RX_BD_SPACE_BASE	(MEM_BASE_ADDR)
#define RX_BD_SPACE_HIGH	(MEM_BASE_ADDR + 0x0000FFFF)
#define TX_BD_SPACE_BASE	(MEM_BASE_ADDR + 0x00010000)
#define TX_BD_SPACE_HIGH	(MEM_BASE_ADDR + 0x0001FFFF)
#define TX_BUFFER_BASE		(MEM_BASE_ADDR + 0x00100000)
#define RX_BUFFER_BASE		(MEM_BASE_ADDR + 0x00300000)
#define RX_BUFFER_HIGH		(MEM_BASE_ADDR + 0x004FFFFF)

#ifndef SDT
#ifdef XPAR_INTC_0_DEVICE_ID
#define INTC_DEVICE_ID          XPAR_INTC_0_DEVICE_ID
#else
#define INTC_DEVICE_ID          XPAR_SCUGIC_SINGLE_DEVICE_ID
#define UART_INT_IRQ_ID		XPAR_XUARTPS_1_INTR
#endif
#endif

/* Timeout loop counter for reset
 */
#define RESET_TIMEOUT_COUNTER	10000

/*
 * Buffer and Buffer Descriptor related constant definition
 */
#define MAX_PKT_LEN		(0x10000) //2^14 * 4 bytes
#define MARK_UNCACHEABLE        0x701

#define SAMPLE_FREQ_MHZ		(100)
#define SAMPLE_DUR_US		(100)
#define NUM_WORDS_RX		(SAMPLE_FREQ_MHZ * SAMPLE_DUR_US)
#define NUM_BYTES_TX		(NUM_WORDS_RX * 4)

/*
 * Number of BDs in the transfer example
 * We show how to submit multiple BDs for one transmit.
 * The receive side get one completion interrupt per cyclic transfer.
 */
#define NUMBER_OF_BDS_PER_PKT		1
#define NUMBER_OF_PKTS_TO_TRANSFER 	1
#define NUMBER_OF_BDS_TO_TRANSFER	(NUMBER_OF_PKTS_TO_TRANSFER * \
		NUMBER_OF_BDS_PER_PKT)

#define NUMBER_OF_CYCLIC_TRANSFERS	100

/* The interrupt coalescing threshold and delay timer threshold
 * Valid range is 1 to 255
 *
 * We set the coalescing threshold to be the total number of packets.
 * The receive side will only get one completion interrupt per cyclic transfer.
 */
#define COALESCING_COUNT		(100)//NUMBER_OF_PKTS_TO_TRANSFER
#define DELAY_TIMER_COUNT		100
#define POLL_TIMEOUT_COUNTER            1000000U
#define NUMBER_OF_EVENTS		1

#ifndef SDT
#ifdef XPAR_INTC_0_DEVICE_ID
#define INTC		XIntc
#define INTC_HANDLER	XIntc_InterruptHandler
#else
#define INTC		XScuGic
#define INTC_HANDLER	XScuGic_InterruptHandler
#endif
#endif

#define AXIS_SWITCH_TX_SI		(0)
#define AXIS_SWITCH_RX_SI		(1)
#define AXIS_SWITCH_DMA_MI		(0)
#define AXIS_SWITCH_TERMINATOR_MI		(1)

#define HW_MM2S_DIR		(0)
#define HW_S2MM_DIR		(1)
#define HW_DMA_RESET	(2)

/**************************** Type Definitions *******************************/

typedef enum {
    RECEIVING_FIRST_ARRAY = 0,
    RECEIVING_SECOND_ARRAY = 1,
    RECEIVING_COMPLETE = 2
} ReceiveState;

/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/
#ifdef XPAR_UARTNS550_0_BASEADDR
static void Uart550_Setup(void);
#endif

static int CheckData(int Length, u8 StartValue);
static void TxCallBack(XAxiDma_BdRing *TxRingPtr);
static void TxIntrHandler(void *Callback);
static void RxCallBack(XAxiDma_BdRing *RxRingPtr);
static void RxIntrHandler(void *Callback);


#ifndef SDT
static int SetupIntrSystem(INTC *IntcInstancePtr,
			   XAxiDma *AxiDmaPtr, u16 TxIntrId, u16 RxIntrId);
static void DisableIntrSystem(INTC *IntcInstancePtr,
			      u16 TxIntrId, u16 RxIntrId);
int AxisSwitch_Init(u16 DeviceId);
int AxisSwitch_Config(u16 DeviceId, u8 SiIndex, u8 MiIndex);
int UartPsIntrExample(INTC *IntcInstPtr, XUartPs *UartInstPtr,
		      u16 DeviceId);
#endif

void Handler(void *CallBackRef, u32 Event, unsigned int EventData);
static int RxSetup(XAxiDma *AxiDmaInstPtr, u32 *DestAddr);
static int TxSetup(XAxiDma *AxiDmaInstPtr);
static int SendPacket(XAxiDma *AxiDmaInstPtr, u32 *SrcAddr, int TxLength);
int UartPsIntrInit(INTC *IntcInstPtr, XUartPs *UartInstPtr, u16 DeviceId);
int mm2s_controller_init(XAxiDma_Config *Config);
int prepare_hw_for_transfer(int transfer_dir);
int mm2s_controller(u32 *SrcAddr, int TxLength);
int s2mm_controller(u32 *SrcAddr, int RxLength);



// Usage
//(*array_ptr)[0] = 123;

//u32 Packet[267911168];
