#ifndef _XTIMER_CONFIG_H
#define _XTIMER_CONFIG_H

#include "xparameters.h"

 /* Sleep Timer */
#define XTIMER_IS_DEFAULT_TIMER
#define XTIMER_NO_TICK_TIMER

#endif /* XTIMER_CONFIG_H */
