# DAT096-M1
The working project files from M1 group for the 2025 version of the DAT096 course from Chalmers University of Technology.

The description of the files provided in this repository are available in DAT096_M1_project_documentation.
